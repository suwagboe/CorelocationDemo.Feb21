//
//  CoreLocationSession.swift
//  CorelocationDemo.Feb21
//
//  Created by Pursuit on 2/21/20.
//  Copyright © 2020 Pursuit. All rights reserved.
//

import Foundation
// this is a swift file
import CoreLocation

class CoreLocationSession: NSObject {
    // why?
    // it is a subclass .. this is an inheritence from another class
    // the subclass has it own ...
    public var locationManager: CLLocationManager // it is of the type
    
    // Everything you want to use for location manager you start inside of the initializer
   override init() {
        locationManager = CLLocationManager()
        super.init()
        locationManager.delegate = self // updates like user changed the location/ there was an error capturing the location
        // request the user's location
    locationManager.requestAlwaysAuthorization()
    locationManager.requestWhenInUseAuthorization()
    
    // the following keys need to be added to the info.plist
    
    /*
     NSLocationAlwaysAndWhenInUseUsageDescription
   
     NSLocationWhenInUseUsageDescription
 */
    
    // get updates for user location
    locationManager.startUpdatingLocation()
    
    }
    

    
}


extension CoreLocationSession: CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("didUpdateLocations: \(locations)")
        // its an array because there are differernt points that will show
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("didFailWithError: \(error)")
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedAlways:
            print("authorizedAlways")
        case .authorizedWhenInUse:
            print("authorizedWhenInUse")
        case .denied:
            print("denied")
        case .notDetermined:
            print("notDetermined")
        case .restricted:
            print("restricted")
        default:
            break // apple may add more cases
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        print("to have user enter in a location/region - didEnterRegion")
    }
    
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        print("didExitRegion")
    }
}
